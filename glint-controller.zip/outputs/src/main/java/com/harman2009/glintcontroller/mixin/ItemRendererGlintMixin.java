package com.harman2009.glintcontroller.mixin;

import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import com.harman2009.glintcontroller.GlintConfig;

@Mixin(ItemRenderer.class)
public class ItemRendererGlintMixin {

	@ModifyArgs(
		method = "renderGlint",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V",
			ordinal = 0
		)
	)
	private static void modifyGlintSpeed(Args args) {
		// Modify texture coordinate offset based on glint speed
		float x = args.get(0);
		args.set(0, x * GlintConfig.glintSpeed);
	}
}
