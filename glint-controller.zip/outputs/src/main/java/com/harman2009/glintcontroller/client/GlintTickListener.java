package com.harman2009.glintcontroller.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import com.harman2009.glintcontroller.GlintControllerConfig;

@Environment(EnvType.CLIENT)
public class GlintTickListener {

	public static void register() {
		ClientTickEvents.START.register(client -> {
			// Glint strength and speed are applied per-frame
			// This listener can be extended for dynamic updates
		});
	}
}
