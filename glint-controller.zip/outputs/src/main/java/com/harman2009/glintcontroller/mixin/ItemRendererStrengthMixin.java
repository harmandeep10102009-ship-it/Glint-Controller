package com.harman2009.glintcontroller.mixin;

import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.VertexConsumer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import com.harman2009.glintcontroller.GlintConfig;

@Mixin(ItemRenderer.class)
public class ItemRendererStrengthMixin {

	@ModifyVariable(
		method = "renderGlint",
		at = @At("HEAD"),
		ordinal = 3
	)
	private static int modifyGlintAlpha(int alpha) {
		// Scale alpha (0-255) by glint strength
		return Math.round(alpha * GlintConfig.glintStrength);
	}
}
